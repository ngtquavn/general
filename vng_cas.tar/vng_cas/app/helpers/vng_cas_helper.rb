module VngCasHelper
end
