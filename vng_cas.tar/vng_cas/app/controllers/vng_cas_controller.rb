require 'net/https'
require 'uri'
require 'json'

class VngCasController < ApplicationController
  helper :custom_fields
  include CustomFieldsHelper

  self.main_menu = false

  # prevents login action to be filtered by check_if_login_required application scope filter
  skip_before_action :check_if_login_required
  # Login request and validation
  def logincas
    if User.current.logged?
      redirect_back_or_default home_url, :referer => true
    else
      if !params.has_key?(:ticket)
        redirect_to 'https://login.vng.com.vn/sso/login?service='+home_url+'login/&flags=3'
      else
        ticket = params[:ticket]
        uri = URI('https://login.vng.com.vn/sso/serviceValidate')
        http = Net::HTTP.new(uri.host, uri.port)
        http.use_ssl = true
        req = Net::HTTP::Get.new(uri.path+'?'+'service='+home_url+'login/&ticket='+ticket+'&format=json')
        resp = http.request(req)
        data = ActiveSupport::JSON.decode resp.body
        if !data["serviceResponse"]["authenticationSuccess"].nil?
          username = data["serviceResponse"]["authenticationSuccess"]["user"]
          user = User.find_by_login(username)
		  user.update_last_login_on! if user && !user.new_record? && user.active?
          if user.nil?
            render :template => "vng_cas/output", :locals => {:username => username, :flag => "invalid"}
          else
            if user.active?
              successful_authentication(user)
              update_sudo_timestamp! # activate Sudo Mode
            else
              
              render :template => "vng_cas/output", :locals => {:username => username, :flag => "locked"}
            end
          end
        else
          redirect_to home_url
        end
      end
    end
  rescue AuthSourceException => e
    logger.error "An error occurred when authenticating #{params[:username]}: #{e.message}"
    render_error :message => e.message
  end

  # Log out current user and redirect to login page
  def logoutcas
    logout_user
    redirect_to 'https://login.vng.com.vn/sso/logout?service='+home_url+'login/'
  end
  
  private
  
  def successful_authentication(user)
    logger.info "Successful authentication for '#{user.login}' from #{request.remote_ip} at #{Time.now.utc}"
    # Valid user
    self.logged_user = user
    # generate a key and set cookie if autologin
    if params[:autologin] && Setting.autologin?
      set_autologin_cookie(user)
    end
    call_hook(:controller_account_success_authentication_after, {:user => user })
    redirect_back_or_default my_page_path
  end

  def set_autologin_cookie(user)
    token = user.generate_autologin_token
    secure = Redmine::Configuration['autologin_cookie_secure']
    if secure.nil?
      secure = request.ssl?
    end
    cookie_options = {
      :value => token,
      :expires => 1.year.from_now,
      :path => (Redmine::Configuration['autologin_cookie_path'] || RedmineApp::Application.config.relative_url_root || '/'),
      :secure => secure,
      :httponly => true
    }
    cookies[autologin_cookie_name] = cookie_options
  end
end
