Redmine::Plugin.register :vng_cas do
  name 'Vng Cas plugin'
  author 'tunv@vng.com.vn'
  description 'This is a plugin for Redmine to use the CAS of VNG '
  version '0.0.1'
  #url 'http://example.com/path/to/plugin'
  #author_url 'http://example.com/about'
end
